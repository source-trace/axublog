set charset utf8;
CREATE TABLE `test_adusers` (
  `id` int(11) NOT NULL auto_increment,
  `adnaa` varchar(25) NOT NULL,
  `adpss` varchar(55) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `adnaa` (`adnaa`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
insert into `test_adusers`(`id`,`adnaa`,`adpss`) values('6','admin','yYxvHseLMURYWjMXuICtH2jsBTQNdXog43es9PZUng');
CREATE TABLE `test_arts` (
  `id` int(11) NOT NULL auto_increment,
  `author` varchar(25) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `htmlname` varchar(100) NOT NULL,
  `type` varchar(25) NOT NULL,
  `hit` int(10) NOT NULL,
  `cdate` datetime NOT NULL,
  `edate` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `title` (`title`,`type`,`edate`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
insert into `test_arts`(`id`,`author`,`title`,`content`,`htmlname`,`type`,`hit`,`cdate`,`edate`) values('1','网络','hello world','欢迎使用 axublog。这是系统自动生成的演示文章。编辑或者删除它，开始您的axublog之旅！','hello-world','art','0','2017-06-10 09:34:32','2017-06-12 10:40:49');
insert into `test_arts`(`id`,`author`,`title`,`content`,`htmlname`,`type`,`hit`,`cdate`,`edate`) values('2','网络','测试2222222','<p>
	测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222
</p>
<p>
	测试2222222测试2222222测试2222222测试2222222
</p>
<p>
	测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222
</p>
<p>
	测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222
</p>
<p>
	测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222测试2222222
</p>','ce_shi_2222222_104227','art','13','2017-06-12 10:41:57','2017-06-12 10:46:38');
CREATE TABLE `test_nav_art` (
  `navid` int(11) NOT NULL,
  `artid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
insert into `test_nav_art`(`navid`,`artid`) values('1','1');
insert into `test_nav_art`(`navid`,`artid`) values('2','1');
insert into `test_nav_art`(`navid`,`artid`) values('3','1');
insert into `test_nav_art`(`navid`,`artid`) values('2','2');
CREATE TABLE `test_navs` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(25) NOT NULL,
  `htmlname` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `type` varchar(25) NOT NULL,
  `fuid` bigint(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`,`type`,`fuid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
insert into `test_navs`(`id`,`name`,`htmlname`,`info`,`type`,`fuid`) values('1','未分类','wei-fenlei','一个分类','tag','0');
insert into `test_navs`(`id`,`name`,`htmlname`,`info`,`type`,`fuid`) values('2','测试','ce_shi_104107','','tag','0');
insert into `test_navs`(`id`,`name`,`htmlname`,`info`,`type`,`fuid`) values('3','下载','xia_zai_104107','','tag','0');
